﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            if (webBrowser1 != null)
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void страницаToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void страницаToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("about:blank");
            name = OpenFileDialog.FileName;
            webBrowser1.Navigate(name);
            label1.Visible = true;
            label2.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            button1.Visible = true;
            ToolStripStatusLabel.Visible = true;
        }
    }
    private void выходToolStripMenuItem_Click(object sender, EventArgs e)
    {
        Close();
    }
    double x = Convert.ToDoble(texBox1.Text);
    double y = Convert.ToDoble(texBox2.Text);
    if ( (x < -2) && (y < 5) )
   {
        toolStripStatusLabel1.Text = "Точка входит в зашифрованную область";
        }
else if ((x == -2) && (y == 2))
    {
    toolStripStatusLabel1.Text = "Точка находится на границе";
    }
    else
    {
    toolStripStatusLabel1.Text = "Точка не входит в зашифрованную область";
     }
    }
   }
}
